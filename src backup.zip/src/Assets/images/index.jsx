import logo from '../images/logo.png'

export const images = {
    logo:logo,
}