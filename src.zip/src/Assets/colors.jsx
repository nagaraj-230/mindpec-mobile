export const colors = {
    btncolor:'#ff902f',
    txtcolor:'#4D5154',
    btncolor2:'#909294',
    borderColor:'#4D5154',
    lightbg:'#e2e4e6',

    bgcolor:'#f7f7f7',
    white:'#fff',
    black:'#000',
    cancelbtn:'#6c757d'
    
    
}